#ifndef EFECTORFINAL_H
#define EFECTORFINAL_H

#include <chrono>
#include <thread>

#include <iostream>
#include <sstream>

#include <iomanip>
using std::setw;

#include <queue>

#include "pieza.h"

class EfectorFinal : public Pieza {
    public:
        //  CONSTRUCTOR
        EfectorFinal();

        //  DESTRUCTOR
        virtual ~EfectorFinal();

        void iniciar();

        void pushTarea(int tarea);
        void pushCiclos(int ciclos);

        //string report();

    private:

        int velocidad;

        void pintar(int iter);
        void sostener(int iter);
        void soltar(int iter);
        void rotar(int iter);
        void cambiarVelocidad(int iter);

        //  Declaración del historial como una cola
        std::queue<int> tareas;
        std::queue<int> ciclos;

};

#endif /* EFECTORFINAL_H */

