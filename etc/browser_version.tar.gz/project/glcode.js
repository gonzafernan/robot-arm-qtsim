Qt.include("lib/three.js")
Qt.include("scripts/LoadModel.js")

THREE.Object3D.prototype.rotateAroundWorldAxis = function() {

    var q1 = new THREE.Quaternion();
    return function ( point, axis, angle ) {

        q1.setFromAxisAngle( axis, angle );

        this.quaternion.multiplyQuaternions( q1, this.quaternion );

        this.position.sub( point );
        this.position.applyQuaternion( q1 );
        this.position.add( point );

        return this;
    };

}();

// CONSTRUCTORES DE LAS PIEZAS
function Pieza(){
    this.mesh = new THREE.Group();
    this.proto_point = new Point();
    this.axis = new THREE.Vector3(0, 0, 0);
    this.point = new THREE.Vector3(this.proto_point.x, this.proto_point.y, this.proto_point.z);
    this.angle = 0;
    this.angle_SetPoint = 0;

    this.updateAxis = function(x, y, z){
        this.axis = new THREE.Vector3(x, y, z);
    }

    this.updatePoint = function(x, y, z){
        this.proto_point.x = x;
        this.proto_point.y = y;
        this.proto_point.z = z;
        this.point = new THREE.Vector3(x, y, z);
    }
    /*
    this.updateAngle = function(v){
        pieza2.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
        pieza3.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
        pieza4.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
        pieza5.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
        pieza2.angle += v;
        // Ajuste para volver a 0 luego de 2*PI
        if (pieza2.angle > 2*Math.PI){
            pieza2.angle -= 2*Math.PI;
        }
    }
    */
}

function Point(){
    this.x = 0;
    this.y = 0;
    this.z = 0;
}

var camera, scene, renderer;

var pieza1;
var pieza2;
var pieza3;
var pieza4;
var pieza5;

function initializeGL(canvas) {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, canvas.width / canvas.height, 0.1, 1000);
    camera.position.z = 30;

    var keyLight = new THREE.DirectionalLight(new THREE.Color('hsl(30, 100%, 75%)'), 1.0);
    keyLight.position.set(-100, 0, 100);

    var fillLight = new THREE.DirectionalLight(new THREE.Color('hsl(240, 100%, 75%)'), 0.75);
    fillLight.position.set(100, 0, 100);

    var backLight = new THREE.DirectionalLight(0xffffff, 1.0);
    backLight.position.set(100, 0, -100).normalize();

    scene.add(keyLight);
    scene.add(fillLight);
    scene.add(backLight);

    /*
     * WARNING
    // FIX BUG ORBIT CONTROL THREE in QT
    var controls = new THREE.OrbitControls(camera, renderer.canvas3d);
    controls.enableDamping = true;
    controls.dampingFactor = 0.25;
    controls.enableZoom = true;
    */

    renderer = new THREE.Canvas3DRenderer(
                { canvas: canvas, antialias: true, devicePixelRatio: canvas.devicePixelRatio });
    renderer.setSize(canvas.width, canvas.height);

    // CREACION DE PIEZAS
    // PIEZA 1
    pieza1 = new Pieza();
    pieza1.updatePoint(0.65, 0, 0.1);
    pieza1.updateAxis(0, 1, 0);

    // PIEZA 2
    pieza2 = new Pieza();
    pieza2.updatePoint(pieza1.proto_point.x + 2.35, pieza1.proto_point.y - 0.9, pieza1.proto_point.z - 0.1);

    // PIEZA 3
    pieza3 = new Pieza();
    pieza3.updatePoint(pieza2.proto_point.x, pieza2.proto_point.y + PIEZA3_LONG, pieza2.proto_point.z);

    pieza4 = new Pieza();
    pieza5 = new Pieza();

    loadModel(); // Script en LoadModel.js

}

function resizeGL(canvas) {
    camera.aspect = canvas.width / canvas.height;
    camera.updateProjectionMatrix();

    renderer.setPixelRatio(canvas.devicePixelRatio);
    renderer.setSize(canvas.width, canvas.height);
}

var PIEZA3_LONG = 7.45;

// VELOCIDAD POR DEFECTO DE ARTICULACIONES
var vel_gdl1 = 0.01;
var vel_gdl2 = 0.01;
var vel_gdl3 = 0.01;

// FLAGS PARA ANALISIS DE ESTADO DE LA MAQUINA
var flag_art1 = 0;
var flag_art2 = 0;
var flag_art3 = 0;

function paintGL(canvas) {

    // MOVIMIENTO DE ARTICULACION 1
    if (pieza2.angle < pieza2.angle_SetPoint - 0.02){ // Se le da tolerancias para que no vibre al llegar a la posición
        update_pieza2_angle(vel_gdl1);
    } else if (pieza2.angle > pieza2.angle_SetPoint + 0.02){
        update_pieza2_angle(-vel_gdl1);
    }
    if ((pieza2.angle > pieza2.angle_SetPoint - 0.02) && (pieza2.angle < pieza2.angle_SetPoint + 0.02)){
        flag_art1 = 1;
    }

    // MOVIMIENTO DE ARTICULACION 2
    if (pieza3.angle < pieza3.angle_SetPoint - 0.02){ // Se le da tolerancias para que no vibre al llegar a la posición
        update_pieza3_angle(vel_gdl2);
    } else if (pieza3.angle > pieza3.angle_SetPoint + 0.02){
        update_pieza3_angle(-vel_gdl2);
    }
    if ((pieza3.angle > pieza3.angle_SetPoint - 0.02) && (pieza3.angle < pieza3.angle_SetPoint + 0.02)){
        flag_art2 = 1;
    }

    // MOVIMIENTO DE ARTICULACION 3
    if (pieza4.angle < pieza4.angle_SetPoint - 0.02){ // Se le da tolerancias para que no vibre al llegar a la posición
        update_pieza4_angle(vel_gdl3);
    } else if (pieza4.angle > pieza4.angle_SetPoint + 0.02){
        update_pieza4_angle(-vel_gdl3);
    }
    if ((pieza4.angle > pieza4.angle_SetPoint - 0.02) && (pieza4.angle < pieza4.angle_SetPoint + 0.02)){
        flag_art3 = 1;
    }

    renderer.render(scene, camera);
}

// ACTUALIZACION DE LA CONSIGNA PARA LA ARTICULACION 1
function on_gdl1Changed(value){
    pieza2.angle_SetPoint = value;
    flag_art1 = 0;
}

function update_pieza2_angle(v){
    pieza2.mesh.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
    pieza3.mesh.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
    pieza4.mesh.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
    pieza5.mesh.rotateAroundWorldAxis(pieza1.point, pieza1.axis, v);
    pieza2.angle += v;
    // Ajuste para volver a 0 luego de 2*PI
    if (pieza2.angle > 2*Math.PI){
        pieza2.angle -= 2*Math.PI;
    }
}

// ACTUALIZACION DE LA CONSIGNA PARA LA ARTICULACION 2
function on_gdl2Changed(value){
    pieza3.angle_SetPoint = value;
    flag_art2 = 0;
}

function update_pieza3_angle(v){
    pieza2.updateAxis(Math.sin(pieza2.angle), 0, Math.cos(pieza2.angle));
    pieza2.updatePoint(pieza1.proto_point.x + 2.35 * Math.cos(pieza2.angle), pieza1.proto_point.y - 0.9, pieza1.proto_point.z - 0.1 - 2.35 * Math.sin(pieza2.angle));

    pieza3.mesh.rotateAroundWorldAxis(pieza2.point, pieza2.axis, v);
    pieza4.mesh.rotateAroundWorldAxis(pieza2.point, pieza2.axis, v);
    pieza5.mesh.rotateAroundWorldAxis(pieza2.point, pieza2.axis, v);
    pieza3.angle += v;
    // Ajuste para volver a 0 luego de 2*PI
    if (pieza3.angle > 2*Math.PI){
        pieza3.angle -= 2*Math.PI;
    }
}

// ACTUALIZACION DE LA CONSIGNA PARA LA ARTICULACION 2
function on_gdl3Changed(value){
    pieza4.angle_SetPoint = value;
    flag_art3 = 0;
}

function update_pieza4_angle(v){

    var aux = - PIEZA3_LONG * Math.sin(pieza3.angle);

    var auxX = pieza1.proto_point.x + 2.35 * Math.cos(pieza2.angle) + aux * Math.cos(pieza2.angle);
    var auxY = pieza1.proto_point.y - 0.9 + PIEZA3_LONG * Math.cos(pieza3.angle);
    var auxZ = pieza1.proto_point.z - 0.1 - 2.35 * Math.sin(pieza2.angle) - aux * Math.sin(pieza2.angle);

    pieza3.updateAxis(Math.sin(pieza2.angle), 0, Math.cos(pieza2.angle));
    pieza3.updatePoint(auxX, auxY, auxZ);

    pieza4.mesh.rotateAroundWorldAxis(pieza3.point, pieza3.axis, v);
    pieza5.mesh.rotateAroundWorldAxis(pieza3.point, pieza3.axis, v);
    pieza4.angle += v;
    // Ajuste para volver a 0 luego de 2*PI
    if (pieza4.angle > 2*Math.PI){
        pieza4.angle -= 2*Math.PI;
    }
}

// ACTUALIZACIÓN DE VELOCIDADES
function on_Vgdl1Changed(value){
    vel_gdl1 = value;
}

function on_Vgdl2Changed(value){
    vel_gdl2 = value;
}

function on_Vgdl3Changed(value){
    vel_gdl3 = value;
}

// INDICADOR
function stateIndicator(){
    var msg;
    if (flag_art1 && flag_art2 && flag_art3){
        msg = false;
    } else {
        msg = true;
    }
    return msg;
}
