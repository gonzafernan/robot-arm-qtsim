#include "pieza.h"

Pieza::Pieza() : Conjunto() {
}

Pieza::~Pieza() {
}


// Obtener y setear posición de la pieza instanciada
double Pieza::getAngle(){
    return this->angle;
}

void Pieza::setAngle(double alfa){
    this->angle = alfa;
    // Agregar try catch (excepciones)
}
