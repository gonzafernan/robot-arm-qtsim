#ifndef CONJUNTO_H
#define CONJUNTO_H

#include <string>
#include <sstream>

#include <iostream>
using std::endl;

class Conjunto {
    public:
        Conjunto();
        Conjunto(const Conjunto& orig);
        virtual ~Conjunto();

        std::string toString();

    private:
        std::string modelo = "Mitsubishi RV-2AJ";
        int gdl = 6;
        int max_load = 2;
        std::string drive_system = "ACservo motor";

};

#endif /* CONJUNTO_H */
