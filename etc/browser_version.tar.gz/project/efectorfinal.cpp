#include "efectorfinal.h"

EfectorFinal::EfectorFinal() : Pieza(){
}

EfectorFinal::~EfectorFinal() {
}

//------------------------------------------------------------------------------
//  FUNCIONES ASOCIADAS A LAS DIFERENTES TAREAS DEL DISPOSITIVO (SON FIGURATIVAS)

void EfectorFinal::iniciar(){
    while (!this->tareas.empty()){
        int actual, iter;
        actual = this->tareas.front();
        iter = this->ciclos.front();
        if (actual == 1){
            this->pintar(iter);
        } else if (actual == 2){
            this->sostener(iter);
        } else if (actual == 3){
            this->soltar(iter);
        } else if (actual == 4){
            this->rotar(iter);
        } else if (actual == 5){
            this->cambiarVelocidad(iter);
        }
        //----- CUIDADO-------
        this->tareas.pop();
        this->ciclos.pop();
        //---------------------
    }
}

/*
 *
 * EXCEPCIÓN:
 *  En consulta se observó que al necesitarse comunicar información
 *  del proceso en "tiempo real", se puede hacer una excepción en el
 *  planteo por capas y utilizar salida estándar cout para informar la
 *  la situación del proceso.
 *
 */
void EfectorFinal::pintar(int iter){
    for (int i=0; i<iter; i++){
        std::this_thread::sleep_for (std::chrono::seconds(1));
        // Se coloca un tiempo muerto que simboliza un ciclo
        //  de la tarea especificada.
        std::cout << "PINTANDO: " << setw(25) << "Cant. ciclos a realizar: "
                << iter << setw(20) << "Ciclo actural: " << i+1 << std::endl;
    }
}

void EfectorFinal::sostener(int iter){
    for (int i=0; i<iter; i++){
        std::this_thread::sleep_for (std::chrono::seconds(1));
        // Se coloca un tiempo muerto que simboliza un ciclo
        //  de la tarea especificada.
        std::cout << "SOSTENIENDO: " << setw(25) << "Cant. ciclos a realizar: "
                << iter << setw(20) << "Ciclo actural: " << i+1 << std::endl;
    }
}
void EfectorFinal::soltar(int iter){
    for (int i=0; i<iter; i++){
        std::this_thread::sleep_for (std::chrono::seconds(1));
        // Se coloca un tiempo muerto que simboliza un ciclo
        //  de la tarea especificada.
        std::cout << "SOLTANDO: " << setw(25) << "Cant. ciclos a realizar: "
                << iter << setw(20) << "Ciclo actural: " << i+1 << std::endl;
    }
}
void EfectorFinal::rotar(int iter){
    for (int i=0; i<iter; i++){
        std::this_thread::sleep_for (std::chrono::seconds(1));
        // Se coloca un tiempo muerto que simboliza un ciclo
        //  de la tarea especificada.
        std::cout << "ROTANDO: " << setw(25) << "Cant. ciclos a realizar: "
                << iter << setw(20) << "Ciclo actural: " << i+1 << std::endl;
    }
}
void EfectorFinal::cambiarVelocidad(int valor){
    this->velocidad = valor;
    std::cout << "Velocidad seteada a V=" << valor << std::endl;
}

//------------------------------------------------------------------------------
//  FUNCIONES ASOCIADAS AL REGISTRO DE LAS OPERACIONES

void EfectorFinal::pushTarea(int tarea){
    this->tareas.push(tarea);
}

void EfectorFinal::pushCiclos(int ciclos){
    this->ciclos.push(ciclos);
}
