#ifndef PIEZA_H
#define PIEZA_H

#include "conjunto.h"

class Pieza : public Conjunto {
    public:
        // CONSTRUCTOR
        Pieza();
        //  DESTRUCTOR
        virtual ~Pieza();

        double getAngle();
        void setAngle(double alfa);

    private:
        double angle = 0;
};

#endif // PIEZA_H
