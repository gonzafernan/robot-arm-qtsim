#include "conjunto.h"

// Constructor
Conjunto::Conjunto() {
}

// Destructor
Conjunto::~Conjunto() {
}

// GET INFORMATION
std::string Conjunto::toString(){
    std::stringstream ss;
    ss << "INFORMACION GENERAL:" << endl
            << "Modelo: " << this->modelo << endl
            << "Grados de libertad: " << this->gdl << endl
            << "Maxima carga admitida en Kg: " << max_load << endl
            << "Sistema de accionamiento: " << this->drive_system << endl;
    return ss.str();
}
