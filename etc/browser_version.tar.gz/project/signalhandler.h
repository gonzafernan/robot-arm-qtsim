#ifndef SIGNALHANDLER_H
#define SIGNALHANDLER_H

#include <QObject>
#include <QQuickItem>
#include <QVariant>
#include <QTimer>

#include <iostream>

#include "baserobot.h"

class SignalHandler : public QObject{
    Q_OBJECT
    public slots:
        void cppSlot(const QString &msg);
        void getSignal(int sgn);
        void update();

    public:
        SignalHandler();
        SignalHandler(BaseRobot *proto);
        void setUpd(QObject *p);
        QObject *getUpd();

    private:
        BaseRobot *br;
        QObject *upd;
};
#endif // SIGNALHANDLER_H
