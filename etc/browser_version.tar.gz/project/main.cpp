#include <QGuiApplication>
#include <QQmlApplicationEngine>

#include <QQmlComponent>
#include <QQmlProperty>
#include <iostream>

#include "baserobot.h"
#include "signalhandler.h"

int main(int argc, char **argv){
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    QQmlComponent component(&engine, "qrc:/main.qml");
    QObject *object = component.create();
    QObject *sliders = object->findChild<QObject*>("sliders");

    QObject *sl_gdl1 = sliders->findChild<QObject*>("gdl1");
    QObject *sl_gdl2 = sliders->findChild<QObject*>("gdl2");
    QObject *sl_gdl3 = sliders->findChild<QObject*>("gdl3");
    QObject *sl_Vgdl1 = sliders->findChild<QObject*>("v_gdl1");
    QObject *sl_Vgdl2 = sliders->findChild<QObject*>("v_gdl2");
    QObject *sl_Vgdl3 = sliders->findChild<QObject*>("v_gdl3");

    QObject *indicator = object->findChild<QObject*>("indicator");

    BaseRobot * br;
    br = new BaseRobot();

    // MANEJADOR DE SEÑALES
    SignalHandler *sh = new SignalHandler(br);
    QObject::connect(object, SIGNAL(qmlSignal(QString)), sh, SLOT(cppSlot(QString)));
    sh->setUpd(indicator);

    br->setState(indicator);

    // Seteo de prueba
    br->setGdl1_i(sl_gdl1);
    br->setGdl2_i(sl_gdl2);
    br->setGdl3_i(sl_gdl3);

    br->setVgdl1_i(sl_Vgdl1);
    br->setVgdl2_i(sl_Vgdl2);
    br->setVgdl3_i(sl_Vgdl3);

    return app.exec();
}
