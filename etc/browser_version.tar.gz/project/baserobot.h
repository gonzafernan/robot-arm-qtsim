#ifndef BASEROBOT_H
#define BASEROBOT_H

#include <QObject>
#include <QQmlProperty>
#include <QTimer>

#include <string>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <istream>

#include "conjunto.h"
#include "pieza.h"
#include "efectorfinal.h"

class BaseRobot : public Conjunto {

    public:
        BaseRobot();
        BaseRobot(const BaseRobot& orig);
        virtual ~BaseRobot();

        void init();
        void loadProgram(const QString &msg);

        void interpreteComando(std::string comando);

        bool getEstado();
        void setEstado(bool valor);

        bool getState();
        void setState(QObject *p);

        void activeRobot();
        void desactiveRobot();

        // INSTANCIACION DE LAS PARTES DEL ROBOT
        Pieza *p1 = new Pieza();
        Pieza *p2 = new Pieza();
        Pieza *p3 = new Pieza();
        Pieza *p4 = new Pieza();
        EfectorFinal *ef = new EfectorFinal();

        // GET SET DE ARTICULACIONES
        double getGdl1();
        void setGdl1(double alfa);
        double getGdl2();
        void setGdl2(double alfa);
        double getGdl3();
        void setGdl3(double alfa);

        void setGdl1_i(QObject *p);
        void setGdl2_i(QObject *p);
        void setGdl3_i(QObject *p);

        // GET SET DE LAS VELOCIDADES
        double getVgdl1();
        void setVgdl1(double alfa);
        double getVgdl2();
        void setVgdl2(double alfa);
        double getVgdl3();
        void setVgdl3(double alfa);

        void setVgdl1_i(QObject *p);
        void setVgdl2_i(QObject *p);
        void setVgdl3_i(QObject *p);

    private:
        bool estado = 0;

        const std::string ip_adress = "192.168.1.143/24";
        const unsigned int PORT = 8003;

        QObject *state;

        // ÁNGULO DE LAS ARTICULACIONES
        double gdl1 = 0;
        double gdl2 = 0;
        double gdl3 = 0;

        // ARTICULACIONES COMO OBJETO RELACIONADO CON LA INTERFAZ
        QObject *gdl1_i;
        QObject *gdl2_i;
        QObject *gdl3_i;

        // VELOCIDAD DE LAS ARTICULACIONES
        double Vgdl1 = 0.01;
        double Vgdl2 = 0.01;
        double Vgdl3 = 0.01;

        // VELOCIDADES COMO OBJETO RELACIONADO CON LA INTERFAZ
        QObject *Vgdl1_i;
        QObject *Vgdl2_i;
        QObject *Vgdl3_i;
};

#endif /* BASEROBOT_H */
