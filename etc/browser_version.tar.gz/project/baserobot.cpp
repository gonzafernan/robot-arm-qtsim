#include "baserobot.h"

BaseRobot::BaseRobot() : Conjunto() {
}

BaseRobot::~BaseRobot() {
}

void BaseRobot::init(){
    this->setVgdl1(0.01);
    this->setGdl1(0);
    this->setVgdl2(0.01);
    this->setGdl2(0);
    this->setVgdl3(0.01);
    this->setGdl3(3.14/2);
}

void BaseRobot::loadProgram(const QString &msg){
    std::ifstream file;
    file.open(msg.toStdString());
    std::cout << "Loading program..." << std::endl;
    std::string comando;
    if (file.is_open()){
        while (std::getline(file, comando)){
            std::cout << comando << std::endl;
            this->interpreteComando(comando);
        }
        file.close();
    } else {
        std::cout << "PROBLEM OPENING FILE" << std::endl;
    }
}

/* ----------------------------------------------------------------------------------------
 *  INTERPRETE DE COMANDO
 *      Las instrucciones disponibles son:
 *      - Consigna de posición: G0AXPY
 *  Donde X es el número de articulación a modificar e Y el ángulo deseado.
 *      - Consigna de velocidad: G1AXVY
 *  Donde X es el número de articulación a modificar e Y la velocidad deseada.
 *      - Homing: G28
 -----------------------------------------------------------------------------------------*/
void BaseRobot::interpreteComando(std::string comando){
    std::cout << comando << std::endl;
    if (comando[1] == '0'){ // Consigna de ángulo
        std::string aux = comando.substr(5, 4);
        char aux1[4];
        strcpy(aux1, aux.c_str());
        if (comando[3] == '1'){
            this->setGdl1(atof(aux1));
        } else if (comando[3] == '2'){
            this->setGdl2(atof(aux1));
        } else if (comando[3] == '3'){
            this->setGdl3(atof(aux1));
        }
    } else if (comando[1] == '1'){ // Consigna de velocidad
        std::string aux = comando.substr(5, 4);
        char aux1[4];
        strcpy(aux1, aux.c_str());
        if (comando[3] == '1'){
            this->setVgdl1(atof(aux1));
        } else if (comando[3] == '2'){
            this->setVgdl2(atof(aux1));
        } else if (comando[3] == '3'){
            this->setVgdl3(atof(aux1));
        }
    } else if (comando[1] == '2' && comando[2] == '8'){ // Comando homing
        std::cout << "HOMING" << std::endl;
        this->init();
    }
}

bool BaseRobot::getEstado(){
    return this->estado;
}

void BaseRobot::setEstado(bool valor){
    this->estado = valor;
}

void BaseRobot::activeRobot(){
    this->setEstado(true);
}

void BaseRobot::desactiveRobot(){
    this->setEstado(false);
}

void BaseRobot::setState(QObject *p){
    this->state = p;
}

bool BaseRobot::getState(){
    bool aux;
    aux = QQmlProperty::read(this->state, "active").toBool();
    return aux;
}

//----------------------------------------------------------------------------
// SET Y GET DE ARTICULACIONES
double BaseRobot::getGdl1(){
    return this->gdl1;
}

void BaseRobot::setGdl1(double alfa){
    this->gdl1 = alfa;
    this->p2->setAngle(alfa);
    this->p3->setAngle(alfa);
    this->p4->setAngle(alfa);
    this->ef->setAngle(alfa);

    QQmlProperty::write(this->gdl1_i, "value", alfa);
}

double BaseRobot::getGdl2(){
    return this->gdl2;
}

void BaseRobot::setGdl2(double alfa){
    this->gdl2 = alfa;
    this->p3->setAngle(alfa);
    this->p4->setAngle(alfa);
    this->ef->setAngle(alfa);

    QQmlProperty::write(this->gdl2_i, "value", alfa);
}

double BaseRobot::getGdl3(){
    return this->gdl3;
}

void BaseRobot::setGdl3(double alfa){
    this->gdl3 = alfa;
    this->p4->setAngle(alfa);
    this->ef->setAngle(alfa);

    QQmlProperty::write(this->gdl3_i, "value", alfa);
}

//----------------------------------------------------------------------------

void BaseRobot::setGdl1_i(QObject *p){
    this->gdl1_i = p;
}

void BaseRobot::setGdl2_i(QObject *p){
    this->gdl2_i = p;
}

void BaseRobot::setGdl3_i(QObject *p){
    this->gdl3_i = p;
}

//----------------------------------------------------------------------------
//  SETEO DE VELOCIDAD DE LAS ARTICULACIONES

double BaseRobot::getVgdl1(){
    return this->Vgdl1;
}

void BaseRobot::setVgdl1(double v){
    this->Vgdl1 = v;
    QQmlProperty::write(this->Vgdl1_i, "value", v);
}

double BaseRobot::getVgdl2(){
    return this->Vgdl2;
}

void BaseRobot::setVgdl2(double v){
    this->Vgdl2 = v;
    QQmlProperty::write(this->Vgdl2_i, "value", v);
}

double BaseRobot::getVgdl3(){
    return this->Vgdl3;
}

void BaseRobot::setVgdl3(double v){
    this->Vgdl3 = v;
    QQmlProperty::write(this->Vgdl3_i, "value", v);
}

//----------------------------------------------------------------------------

void BaseRobot::setVgdl1_i(QObject *p){
    this->Vgdl1_i = p;
}

void BaseRobot::setVgdl2_i(QObject *p){
    this->Vgdl2_i = p;
}

void BaseRobot::setVgdl3_i(QObject *p){
    this->Vgdl3_i = p;
}
