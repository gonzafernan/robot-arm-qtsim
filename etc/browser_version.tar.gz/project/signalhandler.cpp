#include "signalhandler.h"

SignalHandler::SignalHandler(){
}

SignalHandler::SignalHandler(BaseRobot *proto){
    this->br = proto;
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    timer->start(100);
}

void SignalHandler::setUpd(QObject *p){
    this->upd = p;
}

QObject *SignalHandler::getUpd(){
    return this->upd;
}

void SignalHandler::cppSlot(const QString &msg){
    if (msg.contains("G")){
        std::string comando = msg.toStdString();
        this->br->interpreteComando(comando);
    } else if (msg.contains(".txt")){
        this->br->loadProgram(msg);
    } else {
        this->getSignal(msg.toInt());
    }
}

void SignalHandler::update(){
    QMetaObject::invokeMethod(this->getUpd(), "update");
}

void SignalHandler::getSignal(int sgn){
    switch (sgn) {
        case 1:
            std::cout << "ENCENDIDO" << std::endl;
            this->br->init();
            break;
        case 2:
            std::cout << "APAGADO" << std::endl;
            break;
    }
}

/*--------------------------------------------------------------
 *   TIPOS DE SEÑALES:
 *      - 1: Señal de inicio (Botón ENCENDIDO)
 *              El brazo realiza Homing
 *      - 2: Señal de apagado (Botón APAGADO)
 *              El brazo frena su funcionamiento.
 *
 *--------------------------------------------------------------
 */
