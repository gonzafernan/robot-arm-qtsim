#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <caract.h>
#include <QTextStream>
#include <mainwindow.h>
#include <manautom.h>


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);

    ~Widget();

private slots:

    void on_ACTIVAR_clicked();

    void on_DESACTIVAR_clicked();

    void on_CARACT_clicked();

    void on_Archivos_clicked();

    void on_START_SEC_clicked();

    void on_EXIT_clicked();

private:
    Ui::Widget *ui;
    bool estado;
    CARACT caracteristicas;
};

#endif // WIDGET_H
