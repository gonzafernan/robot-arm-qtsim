#ifndef CARACT_H
#define CARACT_H

#include <QWidget>

namespace Ui {
class CARACT;
}

class CARACT : public QWidget
{
    Q_OBJECT


public:
    explicit CARACT(QWidget *parent=0);

    double getVelocBa1(){return VelocBase1;}
    double getVelocBa2(){return VelocBase2;}
    double getVelocBr(){return VelocBrazo;}
    double getAngBa1(){return AnguloBase1;}
    double getAngBa2(){return AnguloBase2;}
    double getAngBr(){return AnguloBrazo;}
    ~CARACT();

private slots:
    void on_AceptarC_clicked();

    void on_CancelarC_clicked();

private:
    Ui::CARACT *ui;

    double VelocBase1;
    double VelocBase2;
    double VelocBrazo;
    double AnguloBase1;
    double AnguloBase2;
    double AnguloBrazo;

};

#endif // CARACT_H
