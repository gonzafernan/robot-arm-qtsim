#include "caract.h"
#include "ui_caract.h"
#include <widget.h>
#include <QTextStream>

CARACT::CARACT(QWidget *parent) :                            //Ventana de CARACTERÍSTICAS
    QWidget(parent),
    ui(new Ui::CARACT)
{

    VelocBase1=0.1;                                          //Valores Iniciales como los que se muestran en los QDoubleSpinBox
    VelocBase2=0.1;                                          //Se pueden cambiar valores max, min e iniciales de los QDoubleSpinBox desde el archivo .ui
    VelocBrazo=0.1;
    AnguloBase1=0;
    AnguloBase2=90;
    AnguloBrazo=0;

    ui->setupUi(this);
}

CARACT::~CARACT()
{
    delete ui;
}

void CARACT::on_AceptarC_clicked()
{
    this->AnguloBase1=ui->ABa1->value();                    //Hay funciones Get edeclaradas en el header
    this->AnguloBase2=ui->ABa2->value();
    this->AnguloBrazo=ui->ABr->value();
    this->VelocBase1=ui->VBa1->value();
    this->VelocBase2=ui->VBa2->value();
    this->VelocBrazo=ui->VBr->value();
    hide();

}

void CARACT::on_CancelarC_clicked()                        //Botón Cancelar
{
    hide();
}

