#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :                                               //Ventana de Menú Principal
    QWidget(parent),
    ui(new Ui::Widget)
{
    estado=false;
    ui->setupUi(this);
    setWindowTitle("Programación Orientada a Objetos");
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_ACTIVAR_clicked()                                               //Botón ENCENDIDO
{
    ui->estado->setText("ENCENDIDO");
    this->estado=true;
}

void Widget::on_DESACTIVAR_clicked()                                            //Botón APAGADO
{
    ui->estado->setText("APAGADO");
    this->estado=false;
}

void Widget::on_CARACT_clicked()                                                //Botón de CARACTERÍSTICAS INICIALES
{
    CARACT * ventana1=new CARACT();
    ventana1->show();
}

void Widget::on_Archivos_clicked()                                              //Botón de SUBIR ARCHIVO
{
    MainWindow * ventana2=new MainWindow();
    ventana2->show();                                                           //Abre ventana de OPEN FILE
}

void Widget::on_START_SEC_clicked()                                             //Botón de EMPEZAR MOVIMIENTO
{
    ManAutom * ventana3=new ManAutom();
    ventana3->show();                                                           //Abre ventana de MODO DE USO
}

void Widget::on_EXIT_clicked()                                                  //Botón de SALIR
{
    hide();
}
