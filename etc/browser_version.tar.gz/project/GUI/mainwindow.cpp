#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :           //Ventana para ABRIR ARCHIVOS
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_action_Open_File_triggered()                //Acción de OPEN FILE
{
   QString fileName= QFileDialog::getOpenFileName
            (this,
             "Text Editor Open File",
             "home/princesita/Documentos",                       //Cambiar USER
             "Texts Files (*.txt);;All Files(*.*)");
    if (!fileName.isEmpty()){
        QFile file(fileName);
        if (file.open(QFile::ReadOnly)){
            ui->textEdit->setPlainText(file.readAll());         //Muestra el contenido del archivo en el primer TextEdit
            ui->textEdit_2->setPlainText(fileName);             //filename es el nombre del archivo, se muestra en el segundo TextEdit
            this->Direcc= fileName;
        }else{
           QMessageBox::warning(
                        this,
                        "Text Editor",
                        tr("Cannot read File %1.\nError: %2")
                        .arg(fileName)
                        .arg(file.errorString()));
        }
    }
}

void MainWindow::on_AceptarF_clicked()                          //Botón Aceptar
{
   QString fileName=this->Direcc;
   QFile file(fileName);
   if (!file.open(QIODevice::ReadOnly)){
       QMessageBox::information(0,"error",file.errorString());
   }
    QTextStream in(&file);
    this->Comandos=in.readAll();                                //Guarda el contenido del Archivo en el QString fileName
    hide();
}


void MainWindow::on_CancelarF_clicked()                         //Botón Cancelar
{
    hide();
}
