#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_action_Open_File_triggered();

    void on_AceptarF_clicked();

    void on_CancelarF_clicked();

private:
    Ui::MainWindow *ui;
    QString Comandos;
    QString Direcc;
};

#endif // MAINWINDOW_H
