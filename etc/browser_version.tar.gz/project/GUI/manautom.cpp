#include "manautom.h"
#include "ui_manautom.h"
#include <mainwindow.h>

ManAutom::ManAutom(QWidget *parent) :                   //Ventana de Modo de Uso
    QWidget(parent),
    ui(new Ui::ManAutom)
{
    ui->setupUi(this);
}

ManAutom::~ManAutom()
{
    delete ui;
}


void ManAutom::on_Archivo_clicked()                     //Botón de Abrir Archivo, abre la misma ventana del OpenFile
{
    MainWindow * ventana4=new MainWindow();
    ventana4->show();
}

void ManAutom::on_pushButton_clicked()
{
    hide();
}
