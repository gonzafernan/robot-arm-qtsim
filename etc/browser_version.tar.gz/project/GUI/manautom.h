#ifndef MANAUTOM_H
#define MANAUTOM_H

#include <QWidget>

namespace Ui {
class ManAutom;
}

class ManAutom : public QWidget
{
    Q_OBJECT

public:
    explicit ManAutom(QWidget *parent = 0);
    ~ManAutom();

private slots:

    void on_Archivo_clicked();

    void on_pushButton_clicked();

private:
    Ui::ManAutom *ui;
};

#endif // MANAUTOM_H
