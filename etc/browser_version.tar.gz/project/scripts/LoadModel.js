Qt.include("OBJLoader.js")
Qt.include("MTLLoader.js")

function loadModel(){
    scene.add(pieza1.mesh);
    scene.add(pieza2.mesh);
    scene.add(pieza3.mesh);
    scene.add(pieza4.mesh);
    scene.add(pieza5.mesh);

    var objLoader = new THREE.OBJLoader();
    objLoader.setPath('qrc:/');

    // BASE DEL ROBOT
    objLoader.load('assets/pieza1.obj', function (object){
        pieza1.mesh.add( object );
        pieza1.mesh.position.y -= 10;
    });

    // ARTICULACIÓN 1
    objLoader.load('assets/pieza2.obj', function (object){
        pieza2.mesh.add(object);
        pieza2.mesh.position.y = pieza1.mesh.position.y;
        pieza2.mesh.position.x = pieza1.mesh.position.x;
        pieza2.mesh.position.z = pieza1.mesh.position.z;

    });
    // ARTICULACIÓN 2
    objLoader.load('assets/pieza3.obj', function (object){
        pieza3.mesh.add(object);
        pieza3.mesh.position.y = pieza2.mesh.position.y;
        pieza3.mesh.position.x = pieza2.mesh.position.x;
        //pieza3.mesh.position.z = pieza4.mesh.position.z; // Puede que haya un error
        pieza3.mesh.position.z = pieza2.mesh.position.z;
    });

    // ARTICULACIÓN 3
    objLoader.load('assets/pieza4.obj', function (object){
        pieza4.mesh.add(object);
        pieza4.mesh.position.y = pieza3.mesh.position.y;
        pieza4.mesh.position.x = pieza3.mesh.position.x;
        pieza4.mesh.position.z = pieza3.mesh.position.z;
    });

    // EFECTOR FINAL
    objLoader.load('assets/pieza5.obj', function (object){
        pieza5.mesh.add(object);
        pieza5.mesh.position.y = pieza4.mesh.position.y;
        pieza5.mesh.position.x = pieza4.mesh.position.x;
        pieza5.mesh.position.z = pieza4.mesh.position.z;
    });
}
